# simple-banking-system-with-java
This is a simple java code to perform simple bank transactions such as creating account, updating balance, retrieving last transaction with all required VALIDATIONS!

SOME CODE :

1)
![CODE1](https://user-images.githubusercontent.com/53445466/64423569-7e248200-d0c4-11e9-926b-80bb72b4f664.png)

2)


![CODE2](https://user-images.githubusercontent.com/53445466/64423771-f0956200-d0c4-11e9-899e-ea46df72d819.png)


3)

![CODE3](https://user-images.githubusercontent.com/53445466/64423791-f723d980-d0c4-11e9-8d2b-222c25e648b1.png)

SOME OUTPUT:

1)

![OP1](https://user-images.githubusercontent.com/53445466/64423809-ff7c1480-d0c4-11e9-8a72-6b5aeea625c0.png)

2)


![OP2](https://user-images.githubusercontent.com/53445466/64423825-060a8c00-d0c5-11e9-95b5-8373f18dcccb.png)

3)


![OP3](https://user-images.githubusercontent.com/53445466/64423835-0b67d680-d0c5-11e9-914e-9b2e068844fc.png)

4)


![OP4](https://user-images.githubusercontent.com/53445466/64423840-10c52100-d0c5-11e9-8b0b-1dbd1df9d1f1.png)


THANK YOU!

PS1: This code was compiled with JAVA 12
PS2: if you are using java 5 or lesser version Console io will not work(it was introduced from java 6), 
      in that case please use InputStreamReader and BufferedReader instead.
      
HAPPY CODING!
